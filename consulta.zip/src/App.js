// En App.js (o cualquier otro componente donde desees usar Navbar)
import React from 'react';
import Navbar from './components/Navbar'; // Ajusta la ruta según tu estructura

function App() {
    return (
        <div className="App">
            <Navbar />
            {/* Aquí va el resto de tu aplicación */}
        </div>
    );
}

export default App;
